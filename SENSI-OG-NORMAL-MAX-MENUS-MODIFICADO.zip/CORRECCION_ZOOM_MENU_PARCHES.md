# Corrección del zoom en los menús de parches

- Se corrigió `neonPatchLayout` para calcular una escala proporcional a las dimensiones reales de la pantalla.
- La misma adaptación se aplica a los menús de Free Fire Normal y Free Fire MAX.
- El contenido mantiene sus proporciones y se ajusta al área disponible para evitar ampliación y recortes laterales en teléfonos con pantallas más pequeñas.
- No se cambiaron los nombres, paquetes ni acciones de los parches.

La compilación y la comprobación física en distintos modelos de teléfono siguen pendientes de ejecutarse en Xcode.
